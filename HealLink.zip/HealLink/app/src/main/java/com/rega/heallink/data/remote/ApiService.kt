package com.rega.heallink.data.remote

interface ApiService {
}